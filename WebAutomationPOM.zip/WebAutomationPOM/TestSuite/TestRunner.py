from unittest import TestLoader, TestSuite, TextTestRunner
from Tests.test_MercuryTours_HomePage import MercuryTours_HomePage
from Tests.test_MercuryTours_Registration import MercuryTours_Registration
from Tests.test_MercuryTours_SignOn import MercuryTours_SignOn
import unittest
from HtmlTestRunner import HTMLTestRunner

if __name__ == "__main__":

    #get all tests
    testcase1 = unittest.TestLoader().loadTestsFromTestCase(MercuryTours_SignOn)
    testcase2 = unittest.TestLoader().loadTestsFromTestCase(MercuryTours_Registration)
    testcase3 = unittest.TestLoader().loadTestsFromTestCase(MercuryTours_HomePage)

    #create a test suite (combing testcase)

    test_suite = unittest.TestSuite()
    test_suite.addTest(testcase1)
    test_suite.addTest(testcase2)
    test_suite.addTest(testcase3)

    #run the suite
    unittest.TextTestRunner(verbosity=3).run(test_suite)

    #outfile = open("/home/krishna/Downloads/chrome/WebAutomationPOM/Reports/sanityTestReport.html", "w")

    #runner = HTMLTestRunner(stream=outfile, title="Sanity Test Report", description="Sanity Tests")

    #runner.run(test_suite)